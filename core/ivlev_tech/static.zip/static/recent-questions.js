

class QuestionDisplay extends React.Component {
    constructor(props) {
        super(props);
        this.state = { question: props.question };
    }

    render () {
        const question = this.state.question;

        return <div class="class-item d-flex align-items-center">
                    <div className="card w-100">
                        <div class="card-header">
                            Рекомендуемые
                        </div>
                        <div className="card-body">
                            <h5 className="card-title">{ question.name }
                              <strong className="float-right">(частота - {question.name})</strong>
                            </h5>
                            <h6 className="card-subtitle mb-2 text-muted">{ question.creator.email }</h6>
                            <p className="card-text">{ question.body }</p>
  
                        </div>
                        <div className="card-footer">
                            <a href={'/ivlev_tech/question/' + question.pk + '/' } className="card-link">View Question</a>
                        </div>
                    </div>
                </div>;
    }
}

class RecentQuestions extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            questions: [],
            currentUrl: props.url,
            nextUrl: null,
            previousUrl: null,
            loading: false
        };
    }

    fetchReviews() {
        if (this.state.loading)
            return;

        this.setState( {loading: true} );

        fetch(this.state.currentUrl, {
            method: 'GET',
            headers: {
                Accept: 'application/json'
            }
        }).then((response) => {
            return response.json()
        }).then((data) => {
            this.setState({
                loading: false,
                questions: data.results,
                nextUrl: data.next,
                previousUrl: data.previous
            })
        })
    }

    componentDidMount() {
        this.fetchReviews()
    }

    loadNext() {
        if (this.state.nextUrl == null)
            return;

        this.state.currentUrl = this.state.nextUrl;
        this.fetchReviews();
    }

    loadPrevious() {
        if (this.state.previousUrl == null)
            return;

        this.state.currentUrl = this.state.previousUrl;
        this.fetchReviews();
    }

    render () {
        if (this.state.loading) {
            return <h5>Loading...</h5>;
        }

        const previousButton = <button
                                className="btn btn-secondary"
                                onClick={ () => { this.loadPrevious() } }
                                disabled={ this.state.previousUrl == null }>
              Previous
            </button>;

        const nextButton = <button className="btn btn-secondary float-right"
                            onClick={ () => { this.loadNext() } }
                            disabled={ this.state.nextUrl == null }>
              Next
            </button>;

        let questionItems;

        if (this.state.questions.length === 0) {
            questionItems = <h5>No question to display.</h5>
        } else {
            questionItems = this.state.questions.map((question) => {
                return <QuestionDisplay key={question.pk} question={question}/>
            })
        }

        return <div class="col-lg-12">
            <div >
                { questionItems }
            </div>
            <div>
                {previousButton}
                {nextButton}
            </div>
        </div>;
    }
}
